---
title: LLaDA-8B-Instruct
emoji: 🌊
colorFrom: blue
colorTo: purple
sdk: gradio
sdk_version: 5.49.1
python_version: "3.12"
app_file: app.py
pinned: false
license: other
startup_duration_timeout: 1h
short_description: Native LLaDA with diffusion and PMI Viterbi decoding
models:
- GSAI-ML/LLaDA-8B-Instruct
---

# LLaDA-8B-Instruct

Loads the official [GSAI-ML/LLaDA-8B-Instruct](https://huggingface.co/GSAI-ML/LLaDA-8B-Instruct) directly in
BF16 on ZeroGPU. Model and tokenizer revision: `08b83a6feb34df1a6011b80c3c00c7563e963b07`.

The interface shares the BYOD Gemma demo's decoding controls: temperature,
top-k, block diffusion, confidence-guided or random retention, PMI Viterbi,
ending delay, early stopping, and the live token visualization. The model
uses its native bidirectional forward pass, chat template, and mask token
126336. This is a comparison using the shared app decoder, not a claim to
reproduce the official benchmark sampler.

PMI uses a separate scorer trained on all 980,000 responses in the existing
training split, retokenized with LLaDA's tokenizer. It covers all 126,464
model output IDs, including output padding beyond the tokenizer vocabulary.
Scoring is PMI, retention confidence is diffusion probability, minimum count
is 1, and clipping is ±2. Edit the constants near the top of `app.py` to
change these defaults. Temperature and top-k are shared controls; bigram
weight is fixed at 0.5. Ending-delay strength remains adjustable.

LLaDA's available strategies are confidence-guided, random, and PMI Viterbi.
The adapter-based autoregressive confidence strategy applies to BYOD models.
The first request may take longer while ZeroGPU allocates hardware.


## Optional repetition-aware PMI Viterbi

Select **PMI Viterbi + Repetition Penalty** to use the block-local transition
score `0.5 * temperature * PMI(a,b) - gamma * C(a,b)`. Gamma defaults to 1.0;
0 reproduces the original PMI decoder. C accumulates earlier expected bigram
occurrences from full-vocabulary diffusion probabilities, updated only after
scoring each position. EOS/EOT pairs are neither penalized nor counted. Retained
tokens remain fixed constraints. Counts reset each iteration and block, without
crossing prompt/block boundaries. There are no additional model forward passes.
The original **Bigram Viterbi** option and generation defaults remain available.


## Adaptive Parallel Decoding

The **Adaptive Parallel Decoding (APD)** checkbox defaults OFF. APD is a
commitment layer after the selected sampling or sequence decoder. Each block
uses a cosine confidence threshold from 0.90 to 0.50, with a 15% warmup. It
commits all qualifying masked positions using their selected token's original
full-vocabulary diffusion probability. Remaining positions stay masked; a
best-confidence fallback makes progress and the final step resolves all masks.
Completed blocks exit early, independently of the convergence-stop checkbox.
Existing EOS/EOT retention delay is respected, with endings retained after
ordinary predictions; whole-answer EOS/EOT stopping still follows Early stopping.
Committed values stay fixed. Optional AR retention scoring and retained-token
revision are bypassed under APD. No additional model forwards, token budgets,
position factors, or grinding-phase detection are used. OFF retains the original
decoding configuration. This implements the requested APD subset, inspired by
[CAI-dLLM](https://arxiv.org/abs/2608.22646), rather than its complete controller.
