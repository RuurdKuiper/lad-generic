---
tags:
- n-gram
---
# BYOD expanded n-gram guidance

Tokenizer-specific bigram and trigram statistics, without diffusion-model weights.
Full original 980,000 response documents plus 800 million added tokens: 90% FineWeb-Edu,
5% Python-Edu and 5% FineMath. Added token budgets are measured separately with each
model tokenizer. Sources, pinned revisions, hashes and exact counts are in training_report.json.

All bigram counts are retained. Trigrams retain counts >=2, including count two;
prefix totals include singleton contributions. Counts never cross document boundaries.
PMI uses the successor marginal; trigram backoff strength is 50. No model retraining.

Sources: https://huggingface.co/datasets/HuggingFaceFW/fineweb-edu,
https://huggingface.co/datasets/Avelina/python-edu-cleaned,
https://huggingface.co/datasets/HuggingFaceTB/finemath.
