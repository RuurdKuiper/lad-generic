---
title: BYOD-Llama-3.1-8B
emoji: 🧬
colorFrom: blue
colorTo: purple
sdk: gradio
sdk_version: 5.49.1
python_version: "3.12"
app_file: app.py
pinned: false
license: other
startup_duration_timeout: 1h
short_description: Masked-diffusion demo for BYOD-Llama-3.1-8B
---

# BYOD-Llama-3.1-8B

Interactive full-precision inference for **BYOD-Llama-3.1-8B**, one of the BYOD
(Build Your Own DLM) models. It uses the exact `final` LoRA checkpoint
from the corresponding experiment and loads its original base model in BF16.
No 4-bit quantization is used.

Generation starts from masked answer positions and refines them in parallel.
Fewer denoising steps than generated tokens provide a sub-autoregressive
inference budget; increasing the step count gives the model more refinement
opportunities.

The interface includes PMI bigram Viterbi, confidence-guided and random
retention, autoregressive confidence, block diffusion, early stopping,
EOS/EOT retention delay, and plain-text output for copying newlines and code.

On Ruurd's Spaces, Viterbi defaults to temperature 2, top-k/candidates 16,
fixed bigram weight 0.5, PMI minimum count 1, clipping ±2, and diffusion
probability for retention confidence. Ending-delay strength defaults to 10
and remains adjustable. The sparse scorer uses the complete 980,000-response
training split, separately tokenized for this model. The scoring and retention
defaults can be edited near the top of `app.py`.

Model: [Ruurd/BYOD-Llama-3.1-8B](https://huggingface.co/Ruurd/BYOD-Llama-3.1-8B)

This is a research demo. Outputs may be inaccurate or inappropriate and
inherit limitations from the original base model.
