---
title: BYOD-Gemma-2-9B
emoji: 🧬
colorFrom: blue
colorTo: purple
sdk: gradio
sdk_version: 5.49.1
python_version: "3.12"
app_file: app.py
pinned: false
license: other
startup_duration_timeout: 1h
short_description: Masked-diffusion demo for BYOD-Gemma-2-9B
---

# BYOD-Gemma-2-9B

Interactive full-precision inference for **BYOD-Gemma-2-9B**, one of the BYOD
(Build Your Own DLM) models. It uses the exact `best` LoRA checkpoint
from the corresponding experiment and loads its original base model in BF16.
No 4-bit quantization is used.

Generation starts from masked answer positions and refines them in parallel.
Fewer denoising steps than generated tokens provide a sub-autoregressive
inference budget; increasing the step count gives the model more refinement
opportunities.

Model: [Ruurd/BYOD-Gemma-2-9B](https://huggingface.co/Ruurd/BYOD-Gemma-2-9B)

This is a research demo. Outputs may be inaccurate or inappropriate and
inherit limitations from the original base model.


## Optional repetition-aware PMI Viterbi

Select **PMI Viterbi + Repetition Penalty** to use the block-local transition
score `0.5 * temperature * PMI(a,b) - gamma * C(a,b)`. Gamma defaults to 1.0;
0 reproduces the original PMI decoder. C accumulates earlier expected bigram
occurrences from full-vocabulary diffusion probabilities, updated only after
scoring each position. EOS/EOT pairs are neither penalized nor counted. Retained
tokens remain fixed constraints. Counts reset each iteration and block, without
crossing prompt/block boundaries. There are no additional model forward passes.
The original **Bigram Viterbi** option and generation defaults remain available.


## Adaptive Parallel Decoding

The **Adaptive Parallel Decoding (APD)** checkbox defaults OFF. APD is a
commitment layer after the selected sampling or sequence decoder. Each block
uses a cosine confidence threshold from 0.90 to 0.50, with a 15% warmup. It
commits all qualifying masked positions using their selected token's original
full-vocabulary diffusion probability. Remaining positions stay masked; a
best-confidence fallback makes progress and the final step resolves all masks.
Completed blocks exit early, independently of the convergence-stop checkbox.
Existing EOS/EOT retention delay is respected, with endings retained after
ordinary predictions; whole-answer EOS/EOT stopping still follows Early stopping.
Committed values stay fixed. Optional AR retention scoring and retained-token
revision are bypassed under APD. No additional model forwards, token budgets,
position factors, or grinding-phase detection are used. OFF retains the original
decoding configuration. This implements the requested APD subset, inspired by
[CAI-dLLM](https://arxiv.org/abs/2608.22646), rather than its complete controller.


## Current simplified interface

Two methods: **Confidence-guided** and **BG + TG Viterbi (Gumbel)**. Guided
Temperature0 is deterministic; positive values add unary Gumbel noise, default0.7.
Bigram weight defaults1. APD, early stopping and EOS/EOT retention remain
available; ending-delay strength is10. Other research controls are hidden.
Set SHOW_LEGACY_DECODING_CONTROLS=True in app.py to restore them.

These tokenizer-specific bigram/trigram counts use all980000 original BYOD
training responses, with matching EOS/truncation policy and no document-crossing
counts. They do not use the larger LLaDA expanded corpus. Reconstructed bigram
and unigram counts were verified exactly against the existing scorer. Trigrams
retain count>=2 and clip corrections to+/-2, with relative weight0.5. No diffusion
model training, extra model forwards or external language model are introduced.
Older research-option descriptions in this file describe retained legacy
implementations, not controls exposed by the simplified interface.
