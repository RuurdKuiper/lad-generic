---
title: BYOD-Qwen2.5-7B
emoji: 🧬
colorFrom: blue
colorTo: purple
sdk: gradio
sdk_version: 5.49.1
python_version: "3.12"
app_file: app.py
pinned: false
license: other
startup_duration_timeout: 1h
short_description: Masked-diffusion demo for BYOD-Qwen2.5-7B
---

# BYOD-Qwen2.5-7B

Interactive full-precision inference for **BYOD-Qwen2.5-7B**, one of the BYOD
(Build Your Own DLM) models. It uses the exact `best` LoRA checkpoint
from the corresponding experiment and loads its original base model in BF16.
No 4-bit quantization is used.

Generation starts from masked answer positions and refines them in parallel.
Fewer denoising steps than generated tokens provide a sub-autoregressive
inference budget; increasing the step count gives the model more refinement
opportunities.

The interface includes PMI bigram Viterbi, confidence-guided and random
retention, autoregressive confidence, block diffusion, early stopping,
EOS/EOT retention delay, and plain-text output for copying newlines and code.

On Ruurd's Spaces, Viterbi defaults to temperature 2, top-k/candidates 16,
fixed bigram weight 0.5, PMI minimum count 1, clipping ±2, and diffusion
probability for retention confidence. Ending-delay strength defaults to 10
and remains adjustable. The sparse scorer uses the complete 980,000-response
training split, separately tokenized for this model. The scoring and retention
defaults can be edited near the top of `app.py`.

Model: [Ruurd/BYOD-Qwen2.5-7B](https://huggingface.co/Ruurd/BYOD-Qwen2.5-7B)

This is a research demo. Outputs may be inaccurate or inappropriate and
inherit limitations from the original base model.


## Current simplified interface

Two methods: **Confidence-guided** and **BG + TG Viterbi (Gumbel)**. Guided
Temperature0 is deterministic; positive values add unary Gumbel noise, default0.7.
Bigram weight defaults1. APD, early stopping and EOS/EOT retention remain
available; ending-delay strength is10. Other research controls are hidden.
Set SHOW_LEGACY_DECODING_CONTROLS=True in app.py to restore them.

These tokenizer-specific bigram/trigram counts use all980000 original BYOD
training responses, with matching EOS/truncation policy and no document-crossing
counts. They do not use the larger LLaDA expanded corpus. Reconstructed bigram
and unigram counts were verified exactly against the existing scorer. Trigrams
retain count>=2 and clip corrections to+/-2, with relative weight0.5. No diffusion
model training, extra model forwards or external language model are introduced.
Older research-option descriptions in this file describe retained legacy
implementations, not controls exposed by the simplified interface.
